import functions_framework
from flask import jsonify, request
import json
import cv2
import os
from google.cloud import storage

# Initialize Google Cloud Storage client
storage_client = storage.Client()

def download_video_from_gcs(bucket_name, source_blob_name, destination_file_name):
    """Downloads a video from Google Cloud Storage."""
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(source_blob_name)
    blob.download_to_filename(destination_file_name)

def upload_image_to_gcs(bucket_name, destination_blob_name, source_file_name):
    """Uploads an image to Google Cloud Storage."""
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    blob.upload_from_filename(source_file_name)

def parse_offset(offset):
    """Parses the offset string into hours, minutes, and seconds."""
    parts = list(map(int, offset.split(':')))
    if len(parts) == 2:  # mm:ss
        return 0, parts[0], parts[1]
    elif len(parts) == 3:  # hh:mm:ss
        return parts[0], parts[1], parts[2]
    else:
        raise ValueError(f"Unexpected offset format: {offset}")



@functions_framework.http
def download_image(request):
    outputbucket = "catalog_digitization_output"
    try:
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid JSON in request"}), 400

        video_uri = data.get('video_uri')
        input_json = data.get('input_json')

        if not video_uri or not input_json:
            return jsonify({"error": "Missing 'video_uri' or 'input_json' in request"}), 400

        # Parse the video URI to get bucket name and blob name
        if video_uri.startswith('gs://'):
            video_uri = video_uri[5:]
        bucket_name, source_blob_name = video_uri.split('/', 1)

        # Download the video from GCS
        local_video_path = '/tmp/downloaded_video.mp4'
        download_video_from_gcs(bucket_name, source_blob_name, local_video_path)

        # Open the video using OpenCV
        video_capture = cv2.VideoCapture(local_video_path)

        if not video_capture.isOpened():
            #return jsonify({"error": "Error opening video file"}), 500
            print({'items':[],'status': 'NotOK', 'msg':"Error opening video file"})
            return jsonify({'items':[],'status': 'NotOK', 'msg':"Error opening video file"}), 500

        frame_rate = video_capture.get(cv2.CAP_PROP_FPS)
        extracted_frames = []

        for item in input_json['items']:
            for keyframe in item['keyframes']:
                offset = keyframe['offset']
                try:
                    hours, minutes, seconds = parse_offset(offset)
                except ValueError as e:
                    #return jsonify({"error": f"Invalid offset format: {offset}"}), 400
                    print({'items':[],'status': 'NotOK', 'msg':f"Invalid offset format: {offset}"})
                    return jsonify({'items':[],'status': 'NotOK', 'msg':f"Invalid offset format: {offset}"}), 400

                frame_number = int((hours * 3600 + minutes * 60 + seconds + 0.4) * frame_rate)
                print(f'frame_number is {frame_number}')
                video_capture.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
                success, frame = video_capture.read()
                if success:
                    frame_filename = f'/tmp/{item["name"].replace(" ", "_")}_{frame_number}.jpg'
                    cv2.imwrite(frame_filename, frame)

                    # Upload the frame to GCS
                    frame_gcs_path = f'frames/{frame_filename.split("/tmp/")[1]}'
                    upload_image_to_gcs(outputbucket, frame_gcs_path, frame_filename)

                    # Add the frame URI to the keyframe
                    keyframe['frame_uri'] = f'gs://{outputbucket}/{frame_gcs_path}'

                    # Remove local frame file
                    os.remove(frame_filename)

        # Clean up
        video_capture.release()
        os.remove(local_video_path)
        print(input_json)
        return jsonify(input_json)


    except Exception as e:
        print({'items':[],'status': 'NotOK', 'msg':str(e)})
        #return jsonify({"error": "Internal Server Error", "message": str(e)}), 500
        return jsonify({'items':[],'status': 'NotOK', 'msg':str(e)}), 500

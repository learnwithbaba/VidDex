import json
from flask import Flask, request, jsonify
import vertexai
from vertexai.generative_models import GenerativeModel, Part
from vertexai.generative_models import SafetySetting, FinishReason

app = Flask(__name__)

# Initialize Vertex AI (You can move this to a global scope if needed)
vertexai.init(project="genai-414108", location="us-central1")

# Model and instructions (Global scope for reuse)
model = GenerativeModel(
    "gemini-1.5-pro-001",
    system_instruction=["""You are an expert video analyst, skilled at precisely identifying and describing objects or items based on what is said about them and when. Your task is to analyze the provided video and generate a JSON output that follows a specific format. This output should identify every object or item mentioned in the video, provide a brief description of each, and specify the exact time (in mm:ss format) they are mentioned. Accuracy is paramount – make sure you correctly match the objects to their descriptions using the verbal cues."""]
)

text1 = """Review this video and list the items described along with the description and price(with units as described in video) in JSON format. Also, give us the time offset for two keyframes corresponding to two distinct views of the item. Provide JSON in the given format- {\"name\":\"\",\"description\":\"\",\"price\":\"\",\"keyframes\":[{\"offset\":\"00:00\",\"view\":\"\"},{\"offset\":\"\",\"view\":\"\"}]}. In case of any issue in video while extracting item details please provide the genuine reason as per the provided JSON schema: {"error": \"\"}"""

generation_config = {
    "max_output_tokens": 8192,
    "temperature": 0,
    "top_p": 0.95,
}

safety_settings = [
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        threshold=SafetySetting.HarmBlockThreshold.BLOCK_ONLY_HIGH
    ),
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
        threshold=SafetySetting.HarmBlockThreshold.BLOCK_ONLY_HIGH
    ),
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
        threshold=SafetySetting.HarmBlockThreshold.BLOCK_ONLY_HIGH
    ),
    SafetySetting(
        category=SafetySetting.HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold=SafetySetting.HarmBlockThreshold.BLOCK_ONLY_HIGH
    )
]

def multiturn_generate_content(uri):
    """Generates content using the PaLM2 model."""
    try:
        video1 = Part.from_uri(
            mime_type="video/mp4",
            uri=uri
        )

        responses = model.generate_content(
            [text1, video1],
            generation_config=generation_config,
            safety_settings=safety_settings,
            stream=True,  # Enable streaming for potential long responses
        )

        # Concatenate streamed response parts
        full_response = "".join([response.text for response in responses])
        #print(f"Full response: {full_response}")
        full_response_remove_ticks = full_response.replace("```json","").replace("```","")
        print(f'full_response_remove_ticks is {full_response_remove_ticks}')
        return json.loads(full_response_remove_ticks)

    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")
        return {'error': 'No items extracted from input video'}
    except Exception as e:
        print(f"An error occurred: {e}")
        return {'error': 'Unable to process the video'}



def get_item_details(request):
    try:

        """API endpoint to process a video and extract item details."""
        request_json = request.get_json(silent=True)
        if not request_json or 'uri' not in request_json:
            print('URI is required')
            return jsonify({'items': [], 'status': 'NotOK', 'msg': 'URI is required'}), 400

        uri = request_json['uri']
        result = multiturn_generate_content(uri)
        print(f'result is: {result}')

        if 'error' in result:
            print(f"error msg is: {result.get('error')}")
            error_msg = result.get('error')
            print({'items':[], 'status': 'NotOK', 'msg': error_msg})
            return jsonify({'items':[], 'status': 'NotOK', 'msg': error_msg}), 500
        else:
            print({'items': result, 'status': 'OK', 'msg': 'Success'})
            return jsonify({'items': result, 'status': 'OK', 'msg': 'Success'}), 200


    except Exception as e:
        #response = ({"error": "Internal Server Error", "message": str(e)}), 500
        response = ({'items':[], 'status': 'NotOK', 'msg': str(e)}), 500
        print(response)
        return jsonify({'items':[], 'status': 'NotOK', 'msg': str(e)}), 500


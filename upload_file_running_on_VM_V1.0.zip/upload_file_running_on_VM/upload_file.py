import os
import uuid
from google.cloud import storage
from flask import Flask, request, jsonify
import ssl

app = Flask(__name__)

# Initialize Google Cloud Storage client
storage_client = storage.Client().from_service_account_json('genai_service_account_credential.json')

def generate_unique_reference():
    return str(uuid.uuid4()).replace('-', '')

@app.route('/upload_file', methods=['POST'])
def upload_file():
    try:
        # Generate a unique reference number
        unique_reference = generate_unique_reference()
        print(f'Process started for reference id {unique_reference}')
        if 'file' not in request.files:
            print("No file part in the request")
            return jsonify({"error": "No file part in the request"}), 400

        file = request.files['file']

        if file.filename == '':
            print("No selected file")
            return jsonify({"error": "No selected file"}), 400

        # Ensure the file is a video
        if not file.filename.lower().endswith(('.mp4', '.avi', '.mov', '.mkv')):
            print(jsonify({"error": "Unsupported file type. Please upload a video file."}))
            return jsonify({"error": "Unsupported file type. Please upload a video file."}), 400

        # Define your bucket name and the target folder in the bucket
        bucket_name = 'catalog_digitization'
        target_folder = 'uploaded_videos'



        # Create a unique filename
        unique_filename = f"{unique_reference}_{file.filename}"
        destination_blob_name = os.path.join(target_folder, unique_filename).replace('\\', '/')

        # Get the bucket
        bucket = storage_client.bucket(bucket_name)

        # Create a new blob
        blob = bucket.blob(destination_blob_name)

        # Use a resumable upload for large files
        blob.upload_from_file(file.stream, content_type=file.content_type, timeout=600)  # 10-minute timeout

        # Construct the gs:// URL
        gs_url = f'gs://{bucket_name}/{destination_blob_name}'
        response = {
            "message": "File uploaded successfully",
            "file_url": gs_url,
            "reference_number": unique_reference
        }, 200
        print(response)
        return response

        """return jsonify({
            "message": "File uploaded successfully",
            "file_url": gs_url,
            "reference_number": unique_reference
        }), 200"""

    except Exception as e:
        response = ({"error": "Internal Server Error", "message": str(e)}), 500
        print(response)
        #return response
        return jsonify({"error": "Internal Server Error", "message": str(e)}), 500

if __name__ == '__main__':
    context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
    certificate_path = 'ssl_package/certificate.crt'
    key_path = 'ssl_package/private.key'
    context.load_cert_chain(certfile=certificate_path, keyfile=key_path)
    #app.run(host='0.0.0.0', port = 9998, debug=False, ssl_context=context)
    app.run(host='0.0.0.0', port = 9998, ssl_context=context)

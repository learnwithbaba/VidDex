import os
import uuid
from google.cloud import storage
from flask import Flask, request, jsonify

app = Flask(__name__)

# Initialize Google Cloud Storage client
storage_client = storage.Client()

def generate_unique_reference():
    return str(uuid.uuid4()).replace('-', '')


def upload_file(request):
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No file part in the request"}), 400

        file = request.files['file']

        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400

        # Ensure the file is a video
        if not file.filename.lower().endswith(('.mp4', '.avi', '.mov', '.mkv')):
            return jsonify({"error": "Unsupported file type. Please upload a video file."}), 400

        # Define your bucket name and the target folder in the bucket
        bucket_name = 'catalog_digitization'
        target_folder = 'uploaded_videos'

        # Generate a unique reference number
        unique_reference = generate_unique_reference()

        # Create a unique filename
        unique_filename = f"{unique_reference}_{file.filename}"
        destination_blob_name = os.path.join(target_folder, unique_filename).replace('\\', '/')

        # Get the bucket
        bucket = storage_client.bucket(bucket_name)

        # Create a new blob
        blob = bucket.blob(destination_blob_name)

        # Use a resumable upload for large files
        blob.upload_from_file(file.stream, content_type=file.content_type, timeout=600)  # 10-minute timeout

        # Construct the gs:// URL
        gs_url = f'gs://{bucket_name}/{destination_blob_name}'

        return jsonify({
            "message": "File uploaded successfully",
            "file_url": gs_url,
            "reference_number": unique_reference
        }), 200

    except Exception as e:
        return jsonify({"error": "Internal Server Error", "message": str(e)}), 500


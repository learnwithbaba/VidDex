from flask import jsonify
from google.cloud import firestore
import functions_framework

# Initialize Firestore DB
db = firestore.Client(database="catalog")
collection_name = 'catalog' 

@functions_framework.http
def upload_item_details(request):
    
    try:
        # Parse the JSON data from the request
        data = request.get_json()

        if not data or 'items' not in data or 'reference_id' not in data:
            return jsonify({"error": "Invalid data format"}), 400

        # Extract items and document ID from the request data
        items = data
        reference_id = data['reference_id']

        # Upload data to Firestore using the specified document ID
        db.collection(collection_name).document(reference_id).set({'items': items})

        return jsonify({"message": "Data uploaded successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
